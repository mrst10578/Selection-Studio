# Selection Studio asset pack

24 generated UI assets, numbered 01–24, optimized as WebP for repository use.
